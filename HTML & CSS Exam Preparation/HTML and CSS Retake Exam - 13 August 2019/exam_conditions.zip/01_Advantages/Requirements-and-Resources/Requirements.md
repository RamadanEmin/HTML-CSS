# 01. Advantages 

## Tasks
* Create a Web page **(HTML5 + CSS3)** that looks and behaves like the provided screenshots
* You have been given all of the **required resources**

## Constraints
* Use the Google fonts - [**"Lato"**](https://fonts.google.com/specimen/Lato)
* Use Font Awesome for the icons
* The web page should open correctly in the latest version of Chrome
* Pixel-perfect implementation is **NOT** required
